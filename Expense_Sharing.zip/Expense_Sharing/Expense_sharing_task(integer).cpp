#include<iostream>
#include<string.h>
#include<stdlib.h>
using namespace std;
char names[100][100];
int pay[100][100];
void main_menu()
{
    cout<<"1.Add an Expense"<<endl<<"2.Show Expenses"<<endl<<"3.Exit program"<<endl;
}
int get_index(int n,char name[100])
{
    int i=0,j,l=strlen(name);
    while(i<n)
    {
        j=0;
        while(j<l)
        {
            if(name[j]==names[i][j])
                j++;
            else
                break;
        }
        if(j==l)
            return i;
        i++;  
    }
    if(i==n)
        return -1;
}
void add_expense(int n)
{
    char name[100];
    
    cout<<"enter the name of the user who paid the money:";
    cin>>name;
    int index=get_index(n,name);
    if(index==-1)
    {
        cout<<"user not found"<<endl;
        return;
    }
    cout<<"enter the expenses he has spent:";
    int expense;
    cin>>expense;
    if(expense<0)
    {
        cout<<"enter valid expense"<<endl;
        return;
    }
    float sum=expense/n;
    for(int i=0;i<n;i++)
    {
        if(i!=index)
        {
            if(pay[index][i]==0)
                pay[i][index]+=sum;
            else
            {
                if(pay[index][i]!=0 && pay[index][i]<sum)
                {
                    pay[i][index]=sum-pay[index][i];
                    pay[index][i]=0;
                }
                else if(pay[index][i]!=0 && pay[index][i]>=sum)
                {
                    pay[index][i]=pay[index][i]-sum;
                    pay[i][index]=0;
                }
            }
        }
    }
    // cout<<index<<endl; 
}
void show_expense(int n)
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
            cout<<pay[i][j]<<"   ";
        cout<<endl;
    }
}
int main()
{
    int n;
    cout<<"enter the no of users:"<<endl;
    cin>>n;
    cout<<"enter the names:"<<endl;
    for(int i=0;i<n;i++)
        cin>>names[i];
    system("cls");
    main_menu();
    int selection;
    cin>>selection;
    while(selection!=3)
    {
        if(selection==1)   
            add_expense(n);
        else if(selection==2)
            show_expense(n);
        else
            cout<<"invalid selection,please try again!!!"<<endl;
        main_menu();
        cin>>selection;
        
    }
    cout<<"program terminated";
}   
